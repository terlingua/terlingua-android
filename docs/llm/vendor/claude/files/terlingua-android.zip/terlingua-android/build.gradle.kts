plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.room3) apply false
}

tasks.register("testAll") {
    group = "verification"
    description = "Runs content compiler tests and app unit/Compose UI tests."
    dependsOn(gradle.includedBuild("build-logic").task(":test"), ":app:testDebugUnitTest")
}
